<?php
  require 'config/config.php';
  $data = [];
  
  if(isset($_POST['search'])) {
    // Get data from FORM
    $keywords = $_POST['keywords'];
    $location = $_POST['location'];

    //keywords based search
    $keyword = explode(',', $keywords);
    $concats = "(";
    $numItems = count($keyword);
    $i = 0;
    foreach ($keyword as $key => $value) {
      # code...
      if(++$i === $numItems){
         $concats .= "'".$value."'";
      }else{
        $concats .= "'".$value."',";
      }
    }
    $concats .= ")";
  //end of keywords based search
  
  //location based search
    $locations = explode(',', $location);
    $loc = "(";
    $numItems = count($locations);
    $i = 0;
    foreach ($locations as $key => $value) {
      # code...
      if(++$i === $numItems){
         $loc .= "'".$value."'";
      }else{
        $loc .= "'".$value."',";
      }
    }
    $loc .= ")";

  //end of location based search
    
    try {
      //foreach ($keyword as $key => $value) {
        # code...

        $stmt = $connect->prepare("SELECT * FROM room_rental_registrations_apartment WHERE type IN $concats  OR country IN $concats OR country IN $loc OR state IN $concats OR state IN $loc OR city IN $concats OR city IN $loc OR address IN $concats OR address IN $loc OR rooms IN $concats OR landmark IN $concats OR landmark IN $loc ");
        $stmt->execute();
		$data2 = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $connect->prepare("SELECT * FROM room_rental_registrations WHERE type IN $concats  OR country IN $concats OR country IN $loc OR state IN $concats OR state IN $loc OR city IN $concats OR city IN $loc OR rooms IN $concats OR address IN $concats OR address IN $loc OR landmark IN $concats OR landmark IN $loc");
        $stmt->execute();
        $data8 = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $data = array_merge($data2, $data8);

    }catch(PDOException $e) {
      $errMsg = $e->getMessage();
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Management Of Real Estate System</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="assets/css/rent.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">

  </head>

  <body id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Home</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav text-uppercase ml-auto">
           
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#search">Search</a>
            </li>
            
            <?php 
              if(empty($_SESSION['username'])){
                echo '<li class="nav-item">';
                  echo '<a class="nav-link" href="./auth/login.php">Login</a>';
                echo '</li>';
              }else{
                echo '<li class="nav-item">';
                 echo '<a class="nav-link" href="./auth/dashboard.php">Account</a>';
               echo '</li>';
              }
            ?>
            
            <li class="nav-item">
              <a class="nav-link" href="./auth/about.php">About Us</a>
            </li>
            
			
			<li class="nav-item">
              <a class="nav-link" href="./auth/register.php">Register</a>
            </li>
			
			 
            
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead">
      <div class="container">
        <div class="intro-text">
          <div class="intro-lead-in"><h1>WELCOME</h1>
		<h2>MANAGEMENT  OF  REAL  ESTATE  SYSTEM</h2>
       </div>
          <div class="intro-heading text-uppercase">It's Nice To See You<br></div>
        </div>
      </div>
    </header>

     <!-- Search -->
    <section id="search">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Search</h2>
            <h3 class="section-subheading text-muted">Find Your Favourite Property.</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <form action="" method="POST" class="center" novalidate>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input class="form-control" id="keywords" name="keywords" type="text" placeholder="Search(Ex: 1bhk,rent..)" required data-validation-required-message="Please enter keywords">
                    <p class="help-block text-danger"></p>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <input class="form-control" id="location" type="text" name="location" placeholder="Location" required data-validation-required-message="Please enter location.">
                    <p class="help-block text-danger"></p>
                  </div>
                </div>         

                <div class="col-md-2">
                  <div class="form-group">
                    <button id="" class="btn btn-success btn-md text-uppercase" name="search" value="search" type="submit">Search</button>
                  </div>
                </div>
              </div>
            </form>

            <?php
              if(isset($errMsg)){
                echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
              }
              if(count($data) !== 0){
                echo "<h2 class='text-center'>LIST OF PROPERTY DETAILS</h2>";
              }else{
                //echo "<h2 class='text-center' style='color:red;'>Try Some other keywords or Location</h2>";
              }
            ?>        
            <?php 
                foreach ($data as $key => $value) {   
                  
		
					echo '<div class= "card  card bg-light mb-3 card border-success mb-3 "  style="padding:1%;">          
                        <div class="card-block">';
                          // echo '<a class="btn btn-warning float-right" href="update.php?id='.$value['id'].'&act=';if(isset($value['ap_number_of_plats'])){ echo "ap"; }else{ echo "indi"; } echo '">Edit</a>';
                       
						                     
                               
					
						 
						
						echo '<div class="row">
                            <div class="col-4">
                            <h3 >OWNER DETAILS</h3>';
                              echo '<p><b>Owner Name: </b>'.$value['fullname'].'</p>';
                              echo '<p><b>Mobile Number: </b>'.$value['mobile'].'</p>';
                             
                              echo '<p><b>Email: </b>'.$value['email'].'</p>';
                              echo '<p><b>Country: </b>'.$value['country'].'</p><p><b> State: </b>'.$value['state'].'</p>';
                              if ($value['image'] !== 'uploads/') {
                                # code...
                                echo '<p><b>Property Image</b></p><img src="app/'.$value['image'].'"  alt="..." class="rounded" height = "300" width="350">';
                              }
							  
							  
							  echo   '<p><b>Google Map View property</b></p>
                                           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d940.1442017666966!2d81.73422852919319!3d16.509507285102785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTbCsDMwJzM0LjIiTiA4McKwNDQnMDUuMiJF!5e1!3m2!1sen!2sin!4v1623491317701!5m2!1sen!2sin" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>';
                    

						 echo '</div>
                            <div class="col-5">
                            <h3>PROPERTY DETAILS</h3>';
                              // echo '<p><b>Country: </b>'.$value['country'].'<b> State: </b>'.$value['state'].'<b> City: </b>'.$value['city'].'</p>';
                               echo '<p><b>Property Type: </b>'.$value['type'].'</p>';
							  
							  echo '<p><b>Plot Number/Door Name: </b>'.$value['plot_number'].'</p>';

                              if(isset($value['sale'])){
                                echo '<p><b>Sale: </b>'.$value['sale'].'</p>';
                              } 
							  if(isset($value['rent'])){
                                echo '<p><b>Rent: </b>'.$value['rent'].'</p>';
                              } 
                              
                               echo '<p><b> City: </b>'.$value['city'].'</p>';
                               if($value['vacant'] == 0){ 
                                if(isset($value['apartment_name']))                         
                                  echo '<div class="alert alert-danger" role="alert"><p><b>Apartment Name: </b>'.$value['apartment_name'].'</p></div>';

                                if(isset($value['ap_number_of_plats']))
                                  echo '<div class="alert alert-danger" role="alert"><p><b>Plat Number: </b>'.$value['ap_number_of_plats'].'</p></div>';
								echo '<div class="alert alert-danger" role="alert"><p><b>Sold</b></p></div>';
                              }else{
								  if(isset($value['apartment_name']))                         
                                  echo '<div class="alert alert-success" role="alert"><p><b>Apartment Name: </b>'.$value['apartment_name'].'</p></div>';

                                if(isset($value['ap_number_of_plats']))
                                  echo '<div class="alert alert-success" role="alert"><p><b>Plat Number: </b>'.$value['ap_number_of_plats'].'</p></div>';
                                echo '<div class="alert alert-success" role="alert"><p><b>Available</b></p></div>';
                              }
                             
                              echo '<p><b>Address: </b>'.$value['address'].'</p><p><b> Landmark(Latitude and Longitude): </b>'.$value['landmark'].'</p>';
							
							  
                          echo '</div>
                            <div class="col-3">
                            <h3>OTHER DETAILS</h3>';
                            if(isset($value['own'])){
											echo '<p><b>Purpose: </b>'.$value['purpose'].'</p>';
											echo '<p><b>Floor: </b>'.$value['floor'].'</p>';
											}
							
							echo '<p><b>Available Rooms: </b>'.$value['rooms'].'</p>';
							echo '<p><b>Facilities: </b>'.$value['accommodation'].'</p>';
                            echo '<p><b>Description: </b>'.$value['description'].'</p>';
                             if(isset($value['area'])){
												echo '<p><b>Available Area: </b>'.$value['area'].'</p>';}
                               echo '<p><b>To View Exact Property Location In Google Map</b>';
							  echo '<p><b>Click on View Larger Map in Google Map And Then Paste</b>';
							  echo '<p><b>Latitude and Longitude Location In Search Bar</b>';							  
                            echo '</div>
							
                          </div>              
                         </div>
                      </div>';
                     
				  
				}
              ?>              
          </div>
        </div>
      </div>
      <br><br><br><br><br><br>
    </section>    

 

 <!-- Footer -->
    <footer style="background-color: #8C985B ;">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <b> MRES Website 2021</b>
          </div>
          
		  
    </footer>
	
	
	

    <!-- Bootstrap core JavaScript -->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="assets/plugins/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="assets/js/jqBootstrapValidation.js"></script>
  

    <!-- Custom scripts for this template -->
    <script src="assets/js/rent.js"></script>
  </body>
</html>
