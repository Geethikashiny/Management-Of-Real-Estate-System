
<?php
	require '../config/config.php';
	if(empty($_SESSION['username']))
		header('Location: login.php');
	?>
<html>


<?php include '../include/header.php';?>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color:#212529;" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="../index.php">Home</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		</button>	
		</div>
		
	</nav>
<head><title>ABOUT US</title></head>
<section id="services">	
<b> ABOUT US </b>
	
<body>
	<div align="center">
		<div style=" border: solid 2px #006D9C; " align="left">
</body>

<h1 style="color:tomato">WELCOME TO MRES</h1>

<h3>A Real estate business is a business entity that deals with the selling, management  of real estate properties.</h3>
<h3>Real estate refers to producing and selling property.</h3>
<h3>This our Website Management Of Real Estate System.</h3>
<p>
<h4 style="color:blue">CONTACT US :</h4> 
<h5>EMAIL : chegondigeethika02@gmail.com</h5>
</P>
<p>
<p>
<h6>2021 MANAGEMENT OF REAL ESTATE SYSTEM PROJECT (MRES).</h6>
</p>
</p>
</section>
		
</html>
<?php include '../include/footer.php';?>