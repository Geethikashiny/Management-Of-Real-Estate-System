<?php
	require '../config/config.php';
	if(empty($_SESSION['username']))
		header('Location: login.php');

	if($_SESSION['role'] == 'admin'){
		$stmt = $connect->prepare('SELECT count(*) as register_user FROM users');
		$stmt->execute();
		$count = $stmt->fetch(PDO::FETCH_ASSOC);


		$stmt = $connect->prepare('SELECT count(*) as total_rent FROM room_rental_registrations');
		$stmt->execute();
		$total_rent = $stmt->fetch(PDO::FETCH_ASSOC);

		$stmt = $connect->prepare('SELECT count(*) as total_rent_apartment FROM room_rental_registrations_apartment');
		$stmt->execute();
		$total_rent_apartment = $stmt->fetch(PDO::FETCH_ASSOC);
	}

	
?>
<?php include '../include/header.php';?>	
	<!-- Header nav -->	
	<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#212529;" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="../index.php">Home</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav text-uppercase ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="#"><?php echo $_SESSION['fullname']; ?> <?php if($_SESSION['role'] == 'admin'){ echo "(Admin)"; } ?></a>
            </li>
            <li class="nav-item">
              <a href="logout.php" class="nav-link">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	<!-- end header nav -->	
<?php include '../include/side-nav.php';?>
	
	<section class="wrapper" style="margin-left: 16%;margin-top: -11%;">
		<!-- <div class="container"> -->
			<!-- <div class="row"> -->
				<div class="col-md-12">
					<h1 style="color:#923D3F">DASH BOARD</h1>
					<div class="row">						
						<?php 
							if($_SESSION['role'] == 'admin'){ 
								echo '<div class="col-md-3">';
								echo '<a href="../app/users.php"><div class="alert alert-info" role="alert">';
								echo '<b>Registered Users: <span class="badge badge-pill badge-success">'.$count['register_user'].'</span></b>';
								echo '</div></a>';
								echo '</div>';
							} 
						?>	
						<?php 
							if($_SESSION['role'] == 'admin'){ 
								echo '<div class="col-md-4">';
								echo '<a href="../app/list.php"><div class="alert alert-info" role="alert">';
								echo '<b>Uploaded Lands/Houses/Flats : <span class="badge badge-pill badge-success">'.(intval($total_rent['total_rent'])+intval($total_rent_apartment['total_rent_apartment'])).'</span></b>';
								echo '</div></a>';
								echo '</div>';
							} 
						?>
						
						<?php 
							if($_SESSION['role'] == 'user'){ 
								echo '<div class="col-md-8">';
								echo '<h5><b>WELCOME TO  OUR WEBSITE MANAGEMENT OF REAL ESTATE SYSTEM!</h5>',
                                       '<p>Management Of Real Estate System software application that manages the overall operational activities and processes. This website deals with selling the houses, flats, lands, commercial properties all over the world.</p>',
									    '<p>The user uses the google map to search a proper location of a property for easy access. It gives exact location of a property by using Google map.</p>',
									   '<p>FOR MORE PROPERTIES GO TO  <a class="navbar-brand js-scroll-trigger" href="../index.php"> Home</a>PAGE AND SEARCH PROPERTIES AS YOUR WISH. </p>',
									   '<p><b>Find a property,if you want to know further details of a property which you  want to buy.</b></p>',
                                      '<h6 style="color:blue"><b>CONTACT ADMIN', 
									  '<h6>PHONE NUMBER : 	9879879787</h6>', 
                                      '<h6>EMAIL : admin1mres@gmail.com</h6>';
										   
								
					       echo '</div>';
								
								
								
						 
								

							} 
						?>
						
					</div>
				</div>
			<!-- </div> -->
		<!-- </div> -->
	</section>

	
    
	
	