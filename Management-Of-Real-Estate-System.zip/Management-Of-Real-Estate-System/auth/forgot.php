<?php
	require '../config/config.php';
    if(empty($_SESSION['email'])){
	if(isset($_POST['forgotpass']))
		
{
   $email=$_POST['email'];
  
  $newpassword=md5($_POST['newpassword']);
  $sql ="SELECT email FROM users WHERE email=:email";
  $query= $connect->prepare($sql);
  $query->bindParam(':email', $email, PDO::PARAM_STR);
  $query->execute();
  $results = $query -> fetchAll(PDO::FETCH_OBJ);
  if($query->rowCount() > 0)
  {
   $con="update users set password=:newpassword where email=:email";
   $chngpwd1 = $connect->prepare($con);
   $chngpwd1->bindParam(':email', $email, PDO::PARAM_STR);
   $chngpwd1->bindParam(':newpassword', $newpassword, PDO::PARAM_STR);
   $chngpwd1->execute();
   $errMsg = 'Your Password succesfully changed';
}
else {
 $errMsg='Email id is invalid';	
}
}
}
	
	
?>
<?php include '../include/header.php';?>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color:#212529;" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="../index.php">Home</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		</button>	
		</div>
		
	</nav>
	<section id="services">
		<div class="container">
			<div class="row">				
			  <div class="col-md-8 mx-auto">
			  	<div class="alert alert-info" role="alert">
			 <form action="" method="POST" class="center" novalidate>
			
			
			<h2 class="text-center">Forgot Password</h2>
			<div style="margin: 15px">
				
					<p style="width: 350px;">
		
			<b>Email id</b>  <input type="email" name="email" class="form-control" id="email" placeholder=" Email id" required="">
	        </p> 


              <p style="width: 350px;">
                 <b>New  Password</b>
                         <input type="password" class="form-control" name="newpassword" id="newpassword" placeholder="New Password" required="">
              </p>


			<p style="width: 350px;">
               <button type="submit" name="forgotpass" class="btn-primary btn">Change</button>
			   
			</p>
			<?php
				if(isset($errMsg)){
					echo '<div style="color:#FF0000;text-align:center;font-size:17px;">'.$errMsg.'</div>';
				}
			?>
			
			
			
			</form>
			

		</div>
	</section>


