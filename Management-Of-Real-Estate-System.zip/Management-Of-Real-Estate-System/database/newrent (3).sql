-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2021 at 03:38 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newrent`
--

-- --------------------------------------------------------

--
-- Table structure for table `cmps`
--

CREATE TABLE `cmps` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `cmp` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cmps`
--

INSERT INTO `cmps` (`id`, `name`, `cmp`) VALUES
(11, 'Kiran ', 'Cracks in walls'),
(12, 'aruna', 'I need more details'),
(9, 'Anusha', 'wifi not working');

-- --------------------------------------------------------

--
-- Table structure for table `room_rental_registrations`
--

CREATE TABLE `room_rental_registrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plot_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rooms` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accommodation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacant` int(1) NOT NULL DEFAULT 1,
  `user_id` int(10) DEFAULT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_rental_registrations`
--

INSERT INTO `room_rental_registrations` (`id`, `fullname`, `mobile`, `type`, `email`, `country`, `state`, `city`, `landmark`, `rent`, `sale`, `plot_number`, `rooms`, `address`, `accommodation`, `description`, `image`, `other`, `vacant`, `user_id`, `area`) VALUES
(1, 'Mahesh', '8345676567', 'House', 'admin1@gmail.com', 'India', 'Andhra pradesh', 'Vijayawada', '16.522013376728392, 80.64490280506674', '20,000', '80,00,000', '45-889', '2bhk', 'Railway Colony,Satyanarayana Puram', 'wifi', 'well', 'uploads/p1.jpg', '', 0, 1, '1700 sq feet'),
(2, 'Anusha', '7345676997', 'House', 'chet@gmail.com', 'India', 'Andhra Pradesh', 'Vizag', '17.671396730616, 83.1968238151478', '30,000', '50,00,000', '25-3-246', '3bhk', ' 25-3-246, Nukalamma Rd', '---------', 'Good ', 'uploads/p0.jpg', NULL, 1, 1, '2000 sq feet'),
(3, 'Suresh', '8695441101', 'House', 'suresh@gmail.com', 'India', 'Andhra Pradesh', 'Kakinada', '16.97507324701621, 82.25253748260012', '20,000', '65,00,000', '27/A-4', '3bhk', 'Gudari Gunta', 'wifi,fridge', 'Good to see', 'uploads/home.jpeg', NULL, 0, 1, '1600 sq feet'),
(4, 'Ravi Kumar', '9832987635', 'House', 'kumar72@gmail.com', 'India', 'Andhra Pradesh', 'Vizag', '17.689982704686734, 83.10421169935198', '10,000', '75,00,000', '45/1-A', '2bhk', 'Sri Ram Nagar colony', '--------', 'well', 'uploads/p3.jpg', NULL, 1, 1, '2000 sq feet'),
(28, 'Suresh kumar ', '8412563584', 'Land', 'suresh123@gmail.com', 'India', 'Andhra pradesh', 'Kurnool', '15.812863785831102, 78.0118925695575', '--------', '80,00,000', '                            -------', '                                   ------', ' Near Delhi Public School , Kurnool', '                             --------', 'LAND FOR SALE', 'uploads/land1.jpg', NULL, 1, 1, '1600 sq feet');

-- --------------------------------------------------------

--
-- Table structure for table `room_rental_registrations_apartment`
--

CREATE TABLE `room_rental_registrations_apartment` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plot_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apartment_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ap_number_of_plats` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rooms` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `own` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accommodation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_for_sharing` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vacant` int(1) NOT NULL DEFAULT 1,
  `user_id` int(10) DEFAULT NULL,
  `rent` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_rental_registrations_apartment`
--

INSERT INTO `room_rental_registrations_apartment` (`id`, `fullname`, `mobile`, `type`, `email`, `country`, `state`, `city`, `landmark`, `plot_number`, `apartment_name`, `ap_number_of_plats`, `rooms`, `floor`, `purpose`, `own`, `area`, `address`, `accommodation`, `description`, `image`, `open_for_sharing`, `other`, `vacant`, `user_id`, `rent`, `sale`) VALUES
(1, 'Ramu', '7841676561', 'Flat', 'ramu123@gmail.com', 'India', 'Andhra Pradesh', 'Tanuku', '16.75283114832752, 81.68832410407272', '45/8', 'Surampudi Enclave', '101', '2bhk', '5th', 'Residential', 'owner', '1500 sq feet', 'Nethaji Subash Chandra Bose Rd, Venkatarayapuram', 'wifi', 'well ', 'uploads/ap.jpg', NULL, NULL, 1, 1, '20,000', '25,00,000'),
(4, 'Ramya', '9789262124', 'Flat', 'ramya456@gmail.com', 'India', 'Andhra Pradesh', 'Vizag', '17.70680255075474, 83.30743975067354', '4/89', 'Madalasa Appartment', '45', '3bhk', 'Ground Floor', 'Residential', 'owner', '1200 sq feet', '11-5, Official Colony, Krishna Nagar, Maharani Peta', 'wifi', 'Good', 'uploads/p4.jpg', NULL, NULL, 1, 1, '15,000', '30,00,000'),
(15, 'Siddhartha', '8242264404', 'Flat', 'siddu56@gmail.com', 'India', 'Andhra Pradesh', 'Vizianagaram', '18.103803625468856, 83.41190555837397', '47/12', 'Prides Classic Avenue', '501', '3BHK', '4th', 'Residential', 'owner', '1600 sq feet', 'Sai Nath Colony', 'wifi', 'well', 'uploads/ap3.jpg', NULL, NULL, 1, 1, '20,000', '80,00,000');

-- --------------------------------------------------------

--
-- Table structure for table `selected_properties`
--

CREATE TABLE `selected_properties` (
  `id` int(11) NOT NULL,
  `username` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `property_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `selected_properties`
--

INSERT INTO `selected_properties` (`id`, `username`, `property_type`, `owner`, `address`, `date`) VALUES
(2, 'Priya', 'House', 'Anusha', '25-3-246, Nukalamma Rd', '15/04/2021'),
(3, 'Kiran', 'Flat, Appartment Name : Surampudi Enclave', 'Ramu', 'Nethaji Subash Chandra Bose Rd, Venkatarayapuram', '17/05/2021'),
(6, 'Aruna', 'House', 'Mahesh', 'Railway Colony,Satyanarayana Puram', '5/5/2021');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'user'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `mobile`, `username`, `email`, `password`, `role`) VALUES
(1, 'ADMIN', '9879879787', 'admin', 'admin1mres@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(14, 'Kiran Kumar', '7848412165', 'Kiran', 'kiran45@gmail.com', 'b1a5b64256e27fa5ae76d62b95209ab3', 'user'),
(13, 'Priya', '7845621112', 'Priya', 'priya123@gmail.com', '48467d2cc726e8847fbc51f5b0bdc1d1', 'user'),
(15, 'Aruna', '7851658784', 'aruna', 'aruna55@gmail.com', 'd3a28ff91cb58754c40f63161ae5e028', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cmps`
--
ALTER TABLE `cmps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_rental_registrations`
--
ALTER TABLE `room_rental_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room_rental_registrations_mobile_unique` (`mobile`),
  ADD UNIQUE KEY `room_rental_registrations_email_unique` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`,`email`) USING HASH;

--
-- Indexes for table `room_rental_registrations_apartment`
--
ALTER TABLE `room_rental_registrations_apartment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile` (`mobile`,`email`) USING HASH;

--
-- Indexes for table `selected_properties`
--
ALTER TABLE `selected_properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_mobile_unique` (`mobile`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cmps`
--
ALTER TABLE `cmps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `room_rental_registrations`
--
ALTER TABLE `room_rental_registrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `room_rental_registrations_apartment`
--
ALTER TABLE `room_rental_registrations_apartment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `selected_properties`
--
ALTER TABLE `selected_properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
