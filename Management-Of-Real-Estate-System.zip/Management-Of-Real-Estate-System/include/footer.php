    <!-- Bootstrap core JavaScript -->
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../assets/plugins/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="../assets/js/jqBootstrapValidation.js"></script>
    <script src="../assets/js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="../assets/js/rent.js"></script>
  
  
    	 <footer style="background-color: #8C985B  ;">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <b> MRES Website 2021</b>
          </div>
          
    </footer>
